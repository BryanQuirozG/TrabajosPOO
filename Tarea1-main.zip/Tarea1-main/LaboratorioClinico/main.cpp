#include <iostream>
#include <string>
#include <string.h>
#include <conio.h>
#include "Libreria1.h"
#include "Informacion.h"
#include "Medicina.h"
using namespace std;

int main()
{
    fflush(stdin);
    setlocale(LC_ALL,"Spanish");
    encabezado();
    menuP();

    return 0;
}
